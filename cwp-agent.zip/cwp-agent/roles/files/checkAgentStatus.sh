#!/bin/bash
#sudo su
#code for checking status of ids service
touch /cwp/outputfile
chmod 777 //outputfile
touch /cwp/idsfile
chmod 777 /cwp/idsfile
service --status-all | grep -i sisidsdaemon | grep -i loaded | cut -d " " -f5 > /cwp/idsfile
service_status_ids=`cat /cwp/idsfile`
if [ "$service_status_ids" == "loaded" ]
then
        echo "Agent Installation status of IDS service Success" |  tr '\n' '=' >> /cwp/outputfile
        cat /cwp/idsfile >> /cwp/outputfile
else
        echo "Agent Installation status of IDS service Failed" >> /cwp/outputfile
fi

#code for checking status of ips service
touch /cwp/ipsutilfile
chmod 777 /cwp/ipsutilfile
service --status-all | grep -i sisipsutildaemon | grep -i loaded | cut -d " " -f5 > /cwp/ipsutilfile
service_status_ipsutil=`cat /cwp/ipsutilfile`
if [ "$service_status_ipsutil" == "loaded" ]
then
        echo "Agent Installation status of IPSUTIL service Success" |  tr '\n' '=' >> /cwp/outputfile
        cat /cwp/ipsutilfile  >> /cwp/outputfile
else
        echo "Agent Installation status of IPSUTIL service Failed" >> /cwp/outputfile
fi

#code for checking status of ips service
touch /cwp/ipsfile
chmod 777 /cwp/ipsfile
service --status-all | grep -i sisipsdaemon | grep -i loaded | cut -d " " -f5 > /cwp/ipsfile
service_status_ips=`cat /cwp/ipsfile`
if [ "$service_status_ips" == "loaded" ]
then
        echo "Agent Installation status of IPS service Success" |  tr '\n' '=' >> /cwp/outputfile
        cat /cwp/ipsfile  >> /cwp/outputfile
else
        echo "Agent Installation status of IPS service Failed" >> /cwp/outputfile
fi


#code for checking status of caf service
touch /cwp/caffile
chmod 777 /cwp/caffile
service --status-all | grep -i cafagent | grep -i loaded | cut -d " " -f5 > /cwp/caffile
service_status_caf=`cat /cwp/caffile`
if [ "$service_status_caf" == "loaded" ]
then
        echo "Agent Installation status of CAF service Success" |  tr '\n' '=' >> /cwp/outputfile
        cat /cwp/caffile  >> /cwp/outputfile
else
        echo "Agent Installation status of CAF service Failed" >> /cwp/outputfile
fi

#print overall status
cat /cwp/outputfile
